import json
import os

__all__ = ['ErrorHandler', 'windowMethods', 'FileHelper', 'TranslationManager']

FileMan = None
TransMan = None
DEBUG = False