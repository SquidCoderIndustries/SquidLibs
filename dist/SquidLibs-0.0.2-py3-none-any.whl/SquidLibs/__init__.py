__all__ = ['ErrorHandler', 'windowMethods', 'FileHelper', 'TranslationManager']

FileMan = None
TransMan = None
DEBUG = False

import FileHelper,TranslationManager